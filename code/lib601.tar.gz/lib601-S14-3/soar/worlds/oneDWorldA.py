dimensions(8,1.5)

wall((0, 1.5), (8, 1.5))

wall((2, 1),(2.5, 1))

wall((3.25, 1),(3.75, 1))

wall((4.5, 1),(5.0, 1))


initialRobotLoc(1.0, 0.5)
